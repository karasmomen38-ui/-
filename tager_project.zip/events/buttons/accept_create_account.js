const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../config.json');

module.exports = {
    name: 'accept_create_account',
    async execute(interaction, client) {
        if (client.dropData.emails.length === 0) {
            return interaction.reply({ content: 'لا توجد إيميلات دروب متبقية.', ephemeral: true });
        }

        const randomIndex = Math.floor(Math.random() * client.dropData.emails.length);
        const selectedEmail = client.dropData.emails.splice(randomIndex, 1)[0];
        client.dropData.usedEmails.push(selectedEmail);
        
        const { saveDropData } = require('../../utils/loaders');
        await saveDropData(client);

        client.ticketData.set(interaction.channel.id, {
            email: selectedEmail,
            name: client.dropName,
            pass: client.dropPass,
            userId: interaction.user.id,
            ticketId: interaction.channel.id,
            timer: setTimeout(async () => {
                const channel = await client.channels.fetch(interaction.channel.id);
                try {
                    const messages = await channel.messages.fetch({ limit: 10 });
                    const surveyMessage = messages.find(msg => 
                        msg.embeds.length > 0 && 
                        msg.embeds[0].title && 
                        msg.embeds[0].title.includes('استبيان إنشاء حساب')
                    );
                    
                    if (surveyMessage) await surveyMessage.delete();
                } catch (deleteErr) {
                    console.log('⚠️ لم استطع حذف رسالة الاستبيان:', deleteErr);
                }
                
                const emailIndex = client.dropData.usedEmails.findIndex(e => 
                    (typeof e === 'string' ? e : e.email) === selectedEmail
                );
                
                if (emailIndex !== -1) {
                    const emailToReturn = client.dropData.usedEmails.splice(emailIndex, 1)[0];
                    
                    if (typeof emailToReturn === 'string') {
                        client.dropData.emails.push(emailToReturn);
                    } else if (emailToReturn.email) {
                        client.dropData.emails.push(emailToReturn.email);
                    }
                    
                    await saveDropData(client);
                    await channel.send('⏰ انتهى الوقت (10 دقائق)! تم إرجاع الإيميل إلى القائمة المتاحة.');
                    
                    const embedIntro = new EmbedBuilder()
                        .setTitle('شرح نظام التكت')
                        .setDescription(`**نظام دروب**\n\n**راح أعطيك ايميل + اسم عائلة + باسورد + تاريخ + شكل ايميل.**\n\n- لا تعدل أي معلومة.\n- لازم تصنع حساب بنفس البيانات.\n- لما تخلص، اضغط زر "تم الإنشاء".\n- أي استهتار = تبنيد مباشر.\n\nهل أنت جاهز؟ اضغط الزر بالأسفل 👇`);

                    const rowIntro = new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId('drop_system').setLabel('نظام دروب').setStyle(ButtonStyle.Primary),
                            new ButtonBuilder().setCustomId('support_request').setLabel('طلب دعم').setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId('quantity_system').setLabel('أخذ كمية').setStyle(ButtonStyle.Success)
                        );

                    await channel.send({ embeds: [embedIntro], components: [rowIntro] });
                    client.ticketData.delete(interaction.channel.id);
                }
            }, config.timeoutMinutes * 60 * 1000)
        });

        const embedForm = new EmbedBuilder()
            .setTitle(`استبيان إنشاء حساب ⏰ (${config.timeoutMinutes} دقائق)`)
            .setDescription(`معلومات انشاء حساب\n\n**الاسم:** ${client.dropName}\n**اسم العائلة:** ${client.dropName}\n**مواليد الحساب:** 2000/1/1\n**شكل ايميل:** ${selectedEmail}\n**باسورد:** ${client.dropPass}\n\n⏰ لديك ${config.timeoutMinutes} دقائق لإكمال العملية`);

        const rowForm = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder().setCustomId('created_done').setLabel('تم إنشاء').setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId('cancel_form').setLabel('الغاء').setStyle(ButtonStyle.Danger),
                new ButtonBuilder().setCustomId('show_help').setLabel('شرح').setStyle(ButtonStyle.Primary),
                new ButtonBuilder().setCustomId('copy_info').setLabel('Copy').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('request_number').setLabel('طلب رقم').setStyle(ButtonStyle.Secondary)
            );

        try { await interaction.message.delete(); } catch {}
        await interaction.channel.send({ embeds: [embedForm], components: [rowForm] });
        await interaction.deferUpdate();
    }
};