const { saveDropData } = require('../../utils/loaders');

module.exports = {
    name: 'delete_all_emails',
    async execute(interaction, client) {
        client.dropData.emails = [];
        client.dropData.usedEmails = [];
        await saveDropData(client);
        await interaction.reply({ content: '🗑️ تم حذف الحسابات المتوفرة والمستخدمة. الحسابات المؤكدة ما انحذفت.', ephemeral: true });
    }
};