const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../config.json');

module.exports = {
    name: 'quantity_system',
    async execute(interaction, client) {
        const requiredRoleId = config.requiredRoleId;
        if (!interaction.member.roles.cache.has(requiredRoleId)) {
            return interaction.reply({ content: '⛔ تحتاج إلى امتلاك سيرفر شراء ايميلات للحصول على ميزة اخذ كمية او اطلب من مشرفين', ephemeral: true });
        }

        const embed = new EmbedBuilder().setTitle('نظام الكمية').setDescription('اختر عدد الإيميلات التي تريدها');
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('qty_5').setLabel('5').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('qty_10').setLabel('10').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('qty_15').setLabel('15').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('qty_20').setLabel('20').setStyle(ButtonStyle.Primary)
        );

        await interaction.update({ embeds: [embed], components: [row] });
    }
};