const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../config.json');
const { saveDropData, saveTopData } = require('../../utils/loaders');

module.exports = {
    name: 'confirm_created_qty',
    async execute(interaction, client) {
        if (!interaction.member.roles.cache.has(config.allowedRoleId)) {
            return interaction.reply({ content: '⛔ تحتاج إلى رول معين لتأكيد الإنشاء', ephemeral: true });
        }

        const data = client.ticketData.get(interaction.channel.id);
        if (!data) return interaction.reply({ content: '⚠️ لا يوجد بيانات', ephemeral: true });

        try { await interaction.message.delete(); } catch (err) {
            console.log('⚠️ لم استطع حذف الرسالة:', err);
        }

        const allEmails = data.emails;
        allEmails.forEach(email => {
            client.dropData.gmails.push({
                email: email,
                userId: data.userId,
                ticketId: data.ticketId
            });
        });

        client.topData[data.userId] = client.topData[data.userId] || { points: 0 };
        client.topData[data.userId].points += allEmails.length * config.pointsPerEmail;

        client.dropData.usedEmails = client.dropData.usedEmails.filter(used => 
            !allEmails.includes(typeof used === 'string' ? used : used.email)
        );

        const resultEmbed = new EmbedBuilder()
            .setTitle('✅ تم تأكيد إنشاء الإيميلات')
            .setColor('#00ff00')
            .setDescription(`**تم إنشاء ${allEmails.length} إيميل بنجاح**\n\n**النقاط المكتسبة:** ${allEmails.length * config.pointsPerEmail}`)
            .addFields({ 
                name: `الإيميلات المنشأة (${allEmails.length})`, 
                value: allEmails.slice(0, 5).join('\n') + (allEmails.length > 5 ? `\n\nو ${allEmails.length - 5} أكثر...` : '') 
            });

        const actionRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('drop_system').setLabel('نظام دروب').setStyle(ButtonStyle.Primary).setEmoji('📧'),
            new ButtonBuilder().setCustomId('quantity_system').setLabel('أخذ كمية').setStyle(ButtonStyle.Success).setEmoji('🔢'), 
            new ButtonBuilder().setCustomId('support_request').setLabel('طلب دعم').setStyle(ButtonStyle.Secondary).setEmoji('🛠️')
        );

        await interaction.channel.send({ embeds: [resultEmbed], components: [actionRow] });
        await Promise.all([saveDropData(client), saveTopData(client)]);
        client.ticketData.delete(interaction.channel.id);
    }
};