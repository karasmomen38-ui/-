const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../config.json');

module.exports = {
    name: 'open_ticket',
    async execute(interaction, client) {
        const blacklistRoleId = config.blacklistRoleId;
        const userId = interaction.user.id;
        const member = interaction.guild.members.cache.get(userId);

        if (member.roles.cache.has(blacklistRoleId)) {
            await interaction.reply({ content: '**انت محظور بشكل تام من نظام دروب يرجى مراجعة دعم الفني لرؤية سبب**', ephemeral: true });
            return;
        }

        const channel = await interaction.guild.channels.create({
            name: `ticket-${interaction.user.username}`.toLowerCase(),
            type: 0,
            parent: config.ticketCategoryId,
            topic: `Ticket Owner: ${userId}`,
            permissionOverwrites: [
                { id: interaction.guild.roles.everyone, deny: ['ViewChannel'] },
                { id: userId, allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory'] },
                { id: config.supportRoleId, allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory'] }
            ]
        });

        const embedIntro = new EmbedBuilder()
            .setTitle('شرح نظام التكت')
            .setDescription(`**نظام دروب**\n\n**راح أعطيك ايميل + اسم عائلة + باسورد + تاريخ + شكل ايميل.**\n\n- لا تعدل أي معلومة.\n- لازم تصنع حساب بنفس البيانات.\n- لما تخلص، اضغط زر "تم الإنشاء".\n- أي استهتار = تبنيد مباشر.\n\nهل أنت جاهز؟ اضغط الزر بالأسفل 👇`);

        const rowIntro = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('drop_system').setLabel('نظام دروب').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('support_request').setLabel('طلب دعم').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('quantity_system').setLabel('أخذ كمية').setStyle(ButtonStyle.Success)
        );

        await channel.send({ content: `<@${userId}>`, embeds: [embedIntro], components: [rowIntro] });
        await interaction.reply({ content: `📩 تم إنشاء التكت: ${channel}`, ephemeral: true });
    }
};