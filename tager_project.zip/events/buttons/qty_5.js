const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { saveDropData } = require('../../utils/loaders');

async function handleQuantitySelection(quantity, interaction, client) {
    if (client.dropData.emails.length < quantity) {
        return interaction.reply({ 
            content: `⚠️ لا يوجد عدد كافي من الإيميلات (المتاح: ${client.dropData.emails.length})`,
            ephemeral: true 
        });
    }

    const selectedEmails = [];
    for (let i = 0; i < quantity; i++) {
        selectedEmails.push(client.dropData.emails.shift());
    }

    client.ticketData.set(interaction.channel.id, {
        emails: selectedEmails,
        pass: client.dropPass,
        userId: interaction.user.id,
        ticketId: interaction.channel.id
    });

    client.dropData.usedEmails.push(...selectedEmails.map(email => ({ email })));
    await saveDropData(client);

    client.topData[interaction.user.id] = client.topData[interaction.user.id] || { points: 0 };

    const emailList = selectedEmails.map((email, index) => `${index + 1} - ${email}`).join('\n');
    
    const embed = new EmbedBuilder()
        .setTitle(`تم اختيار ${quantity} إيميل`)
        .setDescription(`**الإيميلات:**\n${emailList}\n\n**الباسورد:** ${client.dropPass}`);

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder().setCustomId('return_emails').setLabel('إرجاع').setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId('confirm_created_qty').setLabel('تم إنشاء').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId('copy_emails_qty').setLabel('نسخ الإيميلات').setStyle(ButtonStyle.Primary)
        );

    await interaction.update({ embeds: [embed], components: [row] });
}

module.exports = {
    name: 'qty_5',
    async execute(interaction, client) {
        await handleQuantitySelection(5, interaction, client);
    }
};