const { saveDropData } = require('../../utils/loaders');

module.exports = {
    name: 'move_used_back',
    async execute(interaction, client) {
        const used = client.dropData.usedEmails.map(e => typeof e === 'string' ? e : e.email);
        client.dropData.emails.push(...used);
        client.dropData.usedEmails = [];
        await saveDropData(client);
        await interaction.reply({ content: '✅ تم تحويل جميع الحسابات من "قيد استخدام" إلى "متوفرة".', ephemeral: true });
    }
};