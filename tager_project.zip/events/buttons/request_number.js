const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { saveDropData } = require('../../utils/loaders');

module.exports = {
    name: 'request_number',
    async execute(interaction, client) {
        const data = client.ticketData.get(interaction.channel.id);
        if (!data) return interaction.reply({ content: '⚠️ لا توجد بيانات محفوظة لهذا التكت.', ephemeral: true });

        const emailIndex = client.dropData.usedEmails.findIndex(e => (typeof e === 'string' ? e : e.email) === data.email);
        if (emailIndex !== -1) {
            const emailToReturn = client.dropData.usedEmails.splice(emailIndex, 1)[0];
            if (typeof emailToReturn === 'string') {
                client.dropData.emails.push(emailToReturn);
            } else if (emailToReturn.email) {
                client.dropData.emails.push(emailToReturn.email);
            }

            client.ticketData.delete(interaction.channel.id);
            await saveDropData(client);

            try { await interaction.message.delete(); } catch {}

            const embedIntro = new EmbedBuilder()
                .setTitle('شرح نظام التكت')
                .setDescription(`**نظام دروب**\n\n**راح أعطيك ايميل + اسم عائلة + باسورد + تاريخ + شكل ايميل.**\n\n- لا تعدل أي معلومة.\n- لازم تصنع حساب بنفس البيانات.\n- لما تخلص، اضغط زر "تم الإنشاء".\n- أي استهتار = تبنيد مباشر.\n\nهل أنت جاهز؟ اضغط الزر بالأسفل 👇`);

            const rowIntro = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('drop_system').setLabel('نظام دروب').setStyle(ButtonStyle.Primary),
                new ButtonBuilder().setCustomId('support_request').setLabel('طلب دعم').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('quantity_system').setLabel('أخذ كمية').setStyle(ButtonStyle.Success)
            );

            await interaction.channel.send({ embeds: [embedIntro], components: [rowIntro] });
            return interaction.reply({ content: 'تم الغاء انشاء حساب', ephemeral: true });
        } else {
            return interaction.reply({ content: '⚠️ لم يتم العثور على الإيميل في قائمة قيد الاستخدام.', ephemeral: true });
        }
    }
};