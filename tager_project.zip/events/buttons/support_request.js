const config = require('../../config.json');

module.exports = {
    name: 'support_request',
    async execute(interaction, client) {
        const supportRole = interaction.guild.roles.cache.get(config.supportRoleId);

        if (!supportRole) {
            await interaction.reply({ content: '🚫 لم أتمكن من العثور على رول الدعم.', ephemeral: true });
            return;
        }

        let baseContent = `**تم طلب الدعم الفني**\nراح يتواجد معك دعم فني بعد قليل\n<@&${config.supportRoleId}>`;
        const mainMessage = await interaction.reply({ content: baseContent });

        if (supportRole.members.size === 0) {
            baseContent += `\n⚠️ لا يوجد أي عضو في رول الدعم حالياً.`;
            await mainMessage.edit({ content: baseContent });
            return;
        }

        let count = 0;
        let contacted = [];

        for (const member of supportRole.members.values()) {
            try {
                await member.send(`📩 تم طلب دعم هنا في هذا التكت <#${interaction.channel.id}> رجاء الحضور`);
                count++;
                contacted.push(`${count} - تم اتصال بـ ${member}`);
            } catch {
                console.log(`❌ لم أتمكن من إرسال DM إلى ${member.user.tag}`);
            }
        }

        if (contacted.length > 0) {
            baseContent += `\n${contacted.join("\n")}`;
            await mainMessage.edit({ content: baseContent });
        }
    }
};