module.exports = {
    name: 'top_help',
    async execute(interaction, client) {
        await interaction.reply({
            ephemeral: true,
            content: '**شرح نظام النقاط:**\n\n- كل إيميل دروب تقوم بصنعه وتحفظه في النظام = 2 نقطة\n- النقاط تتراكم حتى لو أعيد تشغيل البوت\n- يمكنك رؤية ترتيبك بين الأعضاء باستخدام الأمر !top'
        });
    }
};