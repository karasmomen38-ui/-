const { saveDropData } = require('../../utils/loaders');

module.exports = {
    name: 'return_emails',
    async execute(interaction, client) {
        const data = client.ticketData.get(interaction.channel.id);
        if (!data) return interaction.reply({ content: 'لا يوجد بيانات للإرجاع', ephemeral: true });

        client.dropData.emails.push(...data.emails);
        client.dropData.usedEmails = client.dropData.usedEmails.filter(e => !data.emails.includes(e.email));
        
        if (client.topData[data.userId]) {
            client.topData[data.userId].points = Math.max(0, client.topData[data.userId].points - (data.emails.length * 2));
        }
        
        await saveDropData(client);
        client.ticketData.delete(interaction.channel.id);

        await interaction.update({ 
            content: '✅ تم إرجاع جميع الإيميلات إلى القائمة المتاحة',
            embeds: [],
            components: [] 
        });
    }
};