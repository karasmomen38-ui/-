const { EmbedBuilder } = require('discord.js');
const config = require('../../config.json');

module.exports = {
    name: 'refresh_top',
    async execute(interaction, client) {
        const topArray = Object.entries(client.topData).map(([userId, data]) => ({
            userId, points: data.points
        })).sort((a, b) => b.points - a.points);

        const embed = new EmbedBuilder()
            .setTitle('🏆 قائمة التوب - أعلى الأعضاء نقاطاً')
            .setDescription('**أعضاء قاموا بصنع أكبر عدد من حسابات دروب**\n\n' +
                topArray.slice(0, 30).map((user, index) =>
                    `> ** #${index + 1} ---> <@${user.userId}> \n ${user.points} نقطة ${config.emojis.ownerEmoji}**`
                ).join('\n\n'))
            .setColor('#0099ff')
            .setFooter({ text: 'كل إيميل دروب = 2 نقطة' });

        await interaction.update({ embeds: [embed] });
    }
};