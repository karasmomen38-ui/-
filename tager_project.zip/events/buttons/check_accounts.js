const config = require('../../config.json');

module.exports = {
    name: 'check_accounts',
    async execute(interaction, client) {
        const data = client.ticketData.get(interaction.channel.id);

        if (!data) {
            return interaction.reply({ content: '⚠️ لا توجد بيانات محفوظة لهذا التكت.', ephemeral: true });
        }

        const gmails = (client.dropData.gmails || []).filter(e => e.ticketId === interaction.channel.id && e.userId === data.userId);
        const count = gmails.length;

        if (count === 0) {
            return interaction.reply({ content: '❌ لا يوجد أي إيميل مرتبط بهذه التكت.', ephemeral: true });
        }

        try {
            await interaction.channel.setName(`${count} ايميلات تحت فحص`);
            await interaction.reply({ content: `✅ تم تغيير اسم التكت إلى: **${count} ايميلات تحت فحص**`, ephemeral: false });
        } catch (err) {
            console.error(err);
            await interaction.reply({ content: '❌ حدث خطأ أثناء تغيير اسم التكت.', ephemeral: true });
        }
    }
};