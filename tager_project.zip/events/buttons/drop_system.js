const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'drop_system',
    async execute(interaction, client) {
        try { await interaction.message.delete(); } catch {}

        const embedDrop = new EmbedBuilder()
            .setTitle('شرح بسيط قبل انشاء الحساب')
            .setDescription('**راح اعطيك معلومات الحين سوي حساب منها طيب؟ اذا ضغطت الغاء ترجع للرسالة السابقة**');

        const rowDrop = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('cancel_form').setLabel('الغاء').setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId('accept_create_account').setLabel('قبول وإنشاء حساب').setStyle(ButtonStyle.Success)
        );

        await interaction.channel.send({ embeds: [embedDrop], components: [rowDrop] });
        await interaction.deferUpdate();
    }
};