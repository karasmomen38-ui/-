module.exports = {
    name: 'copy_all_emails',
    async execute(interaction, client) {
        const currentTicketId = interaction.channel.id;
        const emails = (client.dropData.gmails || []).filter(entry => entry.ticketId === currentTicketId);

        if (emails.length === 0) {
            return interaction.reply({ content: '❌ لا يوجد إيميلات مرتبطة بهذه التكت', ephemeral: true });
        }

        try {
            const emailList = emails.map(e => e.email).join('\n');
            await interaction.user.send(emailList);
            await interaction.user.send('https://en.gmailcheck.com/');
            
            await interaction.reply({ 
                content: '✅ تم إرسال جميع الإيميلات والرابط إلى الخاص', 
                ephemeral: true 
            });
        } catch (error) {
            console.error('فشل إرسال الرسائل الخاصة:', error);
            await interaction.reply({ 
                content: '❌ تعذر إرسال الرسائل الخاصة. تأكد من فتح الخاص لديك', 
                ephemeral: true 
            });
        }
    }
};