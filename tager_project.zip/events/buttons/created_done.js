const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'created_done',
    async execute(interaction, client) {
        const data = client.ticketData.get(interaction.channel.id);
        if (data && data.timer) clearTimeout(data.timer);
        
        const embedCheck = new EmbedBuilder()
            .setTitle('هل صنعت حساب في قوقل؟')
            .setDescription('**(اذا كذبت ولم تصنعه سوف تتبند من سيرفر)**');

        const rowCheck = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('confirm_yes').setLabel('نعم صنعت حساب').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId('confirm_back').setLabel('رجوع').setStyle(ButtonStyle.Secondary)
        );

        try { await interaction.message.delete(); } catch {}
        await interaction.channel.send({ embeds: [embedCheck], components: [rowCheck] });
        await interaction.deferUpdate();
    }
};