const { handleQuantitySelection } = require('./qty_5');

module.exports = {
    name: 'qty_20',
    async execute(interaction, client) {
        await handleQuantitySelection(20, interaction, client);
    }
};