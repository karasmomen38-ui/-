module.exports = {
    name: 'copy_info',
    async execute(interaction, client) {
        const data = client.ticketData.get(interaction.channel.id);
        if (!data) return interaction.reply({ content: '⚠️ لا توجد بيانات محفوظة لهذا التكت.', ephemeral: true });

        try {
            await interaction.user.send(`📋 **معلومات الحساب:**\n\n📧 الإيميل: ${data.email}\n🔐 الباسورد: ${data.pass}`);
            await interaction.reply({ content: '📩 تم إرسال المعلومات في الخاص.', ephemeral: true });
        } catch (err) {
            console.error('❌ فشل إرسال رسالة DM:', err);
            await interaction.reply({ content: '🚫 تعذر إرسال المعلومات في الخاص. تحقق من إعدادات الخصوصية.', ephemeral: true });
        }
    }
};