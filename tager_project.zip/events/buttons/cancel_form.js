const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../config.json');
const { saveDropData } = require('../../utils/loaders');

module.exports = {
    name: 'cancel_form',
    async execute(interaction, client) {
        const data = client.ticketData.get(interaction.channel.id);
        
        if (data && data.timer) clearTimeout(data.timer);
        
        if (data && data.email) {
            const emailIndex = client.dropData.usedEmails.findIndex(e => 
                (typeof e === 'string' ? e : e.email) === data.email
            );
            
            if (emailIndex !== -1) {
                const emailToReturn = client.dropData.usedEmails.splice(emailIndex, 1)[0];
                
                if (typeof emailToReturn === 'string') {
                    client.dropData.emails.push(emailToReturn);
                } else if (emailToReturn.email) {
                    client.dropData.emails.push(emailToReturn.email);
                }
                
                await saveDropData(client);
                client.ticketData.delete(interaction.channel.id);
            }
        }
        
        try { await interaction.message.delete(); } catch {}
        
        const embedIntro = new EmbedBuilder()
            .setTitle('شرح نظام التكت')
            .setDescription(`**نظام دروب**\n\n**راح أعطيك ايميل + اسم عائلة + باسورد + تاريخ + شكل ايميل.**\n\n- لا تعدل أي معلومة.\n- لازم تصنع حساب بنفس البيانات.\n- لما تخلص، اضغط زر "تم الإنشاء".\n- أي استهتار = تبنيد مباشر.\n\nهل أنت جاهز؟ اضغط الزر بالأسفل 👇`);

        const rowIntro = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder().setCustomId('drop_system').setLabel('نظام دروب').setStyle(ButtonStyle.Primary),
                new ButtonBuilder().setCustomId('support_request').setLabel('طلب دعم').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('quantity_system').setLabel('أخذ كمية').setStyle(ButtonStyle.Success)
            );

        await interaction.channel.send({ embeds: [embedIntro], components: [rowIntro] });
        await interaction.deferUpdate();
    }
};