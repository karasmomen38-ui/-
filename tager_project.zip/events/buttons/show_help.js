const config = require('../../config.json');

module.exports = {
    name: 'show_help',
    async execute(interaction, client) {
        await interaction.reply({
            ephemeral: true,
            content: `**📌 شرح نظام الاستبيان والدروب:**\n
1. انسخ ايميل وروح قوقل سويه
2. اذا طلب منك رقم اصغط زر طلب رقم حتى تلغي عملية بدون مشاكب
3. بعد الإنشاء، أكد العملية بزر تم الإنشاء.
4. إن أردت التراجع، استخدم رجوع.

🎥 فيديو شرح كامل: <#${config.channels.tutorialChannel}>`
        });
    }
};