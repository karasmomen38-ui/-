const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'refresh_drop',
    async execute(interaction, client) {
        const availableEmails = client.dropData.emails || [];
        const usedEmails = client.dropData.usedEmails.map(e => typeof e === 'string' ? e : e.email) || [];
        const confirmedCount = (client.dropData.gmails || []).length;

        const embed = new EmbedBuilder()
            .setTitle('📊 إحصائية حسابات دروب')
            .setColor('Blue')
            .addFields(
                { name: `✅ حسابات متوفرة (${availableEmails.length})`, value: availableEmails.length ? availableEmails.map(e => `- ${e}`).join('\n').slice(0, 1024) : 'لا يوجد' },
                { name: `🕓 حسابات قيد الاستخدام (${usedEmails.length})`, value: usedEmails.length ? usedEmails.map(e => `- ${e}`).join('\n').slice(0, 1024) : 'لا يوجد' },
                { name: `📬 حسابات مؤكدة الإنشاء`, value: `عددها: ${confirmedCount}` }
            );

        await interaction.update({ embeds: [embed] });
    }
};