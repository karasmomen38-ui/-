const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../config.json');
const { saveDropData, saveTopData } = require('../../utils/loaders');

module.exports = {
    name: 'confirm_yes',
    async execute(interaction, client) {
        const data = client.ticketData.get(interaction.channel.id);
        if (!data) return interaction.reply({ content: 'لا توجد بيانات لهذا التكت.', ephemeral: true });

        if (!client.topData[data.userId]) client.topData[data.userId] = { points: 0 };
        client.topData[data.userId].points += config.pointsPerEmail;
        await saveTopData(client);

        client.dropData.usedEmails = client.dropData.usedEmails?.filter(e => e !== data.email);
        client.dropData.gmails = client.dropData.gmails || [];
        client.dropData.gmails.push({ email: data.email, userId: data.userId, ticketId: data.ticketId });
        await saveDropData(client);

        const logChannel = interaction.guild.channels.cache.get(config.logChannelId);
        if (logChannel) await logChannel.send(`✅ <@${data.userId}> أكد إنشاء الحساب باستخدام الإيميل: \`${data.email}\` في التكت <#${data.ticketId}>`);

        const embedDone = new EmbedBuilder()
            .setTitle('تم إنشاء الحساب')
            .setDescription('هل تريد إنشاء المزيد من حسابات دروب؟ او تبي دعم يجي يفحص حساباتك؟ اكتب #emails عشان تعرف كم ايميل سويت');

        const rowMore = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('create_more').setLabel('انشاء المزيد من حسابات دروب').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('check_accounts').setLabel('فحص حسابات').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('calc_credit').setLabel('احتساب كريدت').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId('support_request').setLabel('طلب دعم').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('quantity_system').setLabel('أخذ كمية').setStyle(ButtonStyle.Success)
        );

        try { await interaction.message.delete(); } catch {}
        await interaction.channel.send({ embeds: [embedDone], components: [rowMore] });
        await interaction.deferUpdate();
    }
};