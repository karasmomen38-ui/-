const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'confirm_back',
    async execute(interaction, client) {
        const data = client.ticketData.get(interaction.channel.id);
        if (!data) return interaction.reply({ content: 'لا توجد بيانات لاستعادة.', ephemeral: true });

        const embedForm = new EmbedBuilder()
            .setTitle('استبيان إنشاء حساب')
            .setDescription(`معلومات انشاء حساب\n\n**الاسم:** ${client.dropName}\n**اسم العائلة:** ${client.dropName}\n**مواليد الحساب:** 2000/1/1\n**شكل ايميل:** ${data.email}\n**باسورد:** ${client.dropPass}`);

        const rowForm = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder().setCustomId('created_done').setLabel('تم إنشاء').setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId('cancel_form').setLabel('الغاء').setStyle(ButtonStyle.Danger),
                new ButtonBuilder().setCustomId('show_help').setLabel('شرح').setStyle(ButtonStyle.Primary),
                new ButtonBuilder().setCustomId('copy_info').setLabel('Copy').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('request_number').setLabel('طلب رقم').setStyle(ButtonStyle.Secondary)
            );

        try { await interaction.message.delete(); } catch {}
        await interaction.channel.send({ embeds: [embedForm], components: [rowForm] });
        await interaction.deferUpdate();
    }
};