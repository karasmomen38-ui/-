const { handleQuantitySelection } = require('./qty_5');

module.exports = {
    name: 'qty_15',
    async execute(interaction, client) {
        await handleQuantitySelection(15, interaction, client);
    }
};