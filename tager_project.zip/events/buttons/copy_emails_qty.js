module.exports = {
    name: 'copy_emails_qty',
    async execute(interaction, client) {
        const data = client.ticketData.get(interaction.channel.id);
        if (!data) return interaction.reply({ content: '⚠️ لا توجد بيانات محفوظة لهذا التكت.', ephemeral: true });

        try {
            const emailList = data.emails.join('\n');
            await interaction.user.send(emailList);
            await interaction.user.send(`الباسورد: ${data.pass}`);
            await interaction.reply({ content: '📩 تم إرسال الإيميلات في الخاص.', ephemeral: true });
        } catch (err) {
            console.error('❌ فشل إرسال رسالة DM:', err);
            await interaction.reply({ content: '🚫 تعذر إرسال الإيميلات في الخاص. تحقق من إعدادات الخصوصية.', ephemeral: true });
        }
    }
};