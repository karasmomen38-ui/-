const { handleQuantitySelection } = require('./qty_5');

module.exports = {
    name: 'qty_10',
    async execute(interaction, client) {
        await handleQuantitySelection(10, interaction, client);
    }
};