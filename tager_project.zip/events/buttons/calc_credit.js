const config = require('../../config.json');

module.exports = {
    name: 'calc_credit',
    async execute(interaction, client) {
        const data = client.ticketData.get(interaction.channel.id);

        if (!data) {
            return interaction.reply({ content: '⚠️ لا توجد بيانات محفوظة لهذا التكت.', ephemeral: true });
        }

        const gmails = (client.dropData.gmails || []).filter(e => e.ticketId === interaction.channel.id && e.userId === data.userId);
        const count = gmails.length;

        if (count === 0) {
            return interaction.reply({ content: '❌ لا يوجد أي إيميل مرتبط بهذه التكت.', ephemeral: true });
        }

        const totalCredit = count * config.emailPrice;

        return interaction.reply({
            content: `**عدد ايميلات التكت:** ${count}\n\n**ستحصل على:** ${totalCredit.toLocaleString()}`,
            ephemeral: true
        });
    }
};