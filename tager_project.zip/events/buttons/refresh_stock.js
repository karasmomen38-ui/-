const { EmbedBuilder } = require('discord.js');
const config = require('../../config.json');

module.exports = {
    name: 'refresh_stock',
    async execute(interaction, client) {
        client.lastStockUser = interaction.user.id;
        client.lastStockTime = new Date().toLocaleString();

        const availableCount = client.dropData.emails.length;
        const embed = new EmbedBuilder()
            .setTitle('📦 Stock Drop Emails')
            .setDescription(`**${availableCount} emails**`)
            .setColor('Blue')
            .setImage(config.images.stockImage)
            .setThumbnail(interaction.user.displayAvatarURL({ size: 1024 }))
            .setFooter({ text: `${interaction.user.username} • ${client.lastStockTime}` });

        await interaction.update({ embeds: [embed] });
    }
};