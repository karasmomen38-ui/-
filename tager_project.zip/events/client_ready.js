const { Events } = require('discord.js');
const { loadDropData, loadTopData } = require('../utils/loaders');

module.exports = {
    name: Events.ClientReady,
    once: true,
    async execute(client) {
        console.log(`✅ Logged in as ${client.user.tag}`);
        
        await loadDropData(client);
        await loadTopData(client);
        
        const guild = await client.guilds.fetch(client.config.guildId);
        if (guild) {
            const cmds = [];
            for (const cmd of client.commands.values()) {
                cmds.push(cmd.data.toJSON());
            }
            await guild.commands.set(cmds);
            console.log('✅ Slash commands registered.');
        }
    }
};