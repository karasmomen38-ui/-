const { Events, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config.json');
const fs = require('fs-extra');

module.exports = {
    name: Events.MessageCreate,
    async execute(message, client) {
        if (message.author.bot) return;

        // ⛔ تحقق من وجود الملف
        const dropPath = './drop.json';
        if (!fs.existsSync(dropPath)) return;

        const data = JSON.parse(fs.readFileSync(dropPath));

        // ✅ أمر #emails مع زر Copy All
        if (message.content.toLowerCase().startsWith('#emails')) {
            const allowedRoleId = config.allowedRoleId;
            
            if (!message.member.roles.cache.has(allowedRoleId)) {
                return message.reply('🚫 هذا الأمر خاص بالمشرفين فقط');
            }

            const currentTicketId = message.channel.id;
            const emails = (client.dropData.gmails || []).filter(entry => entry.ticketId === currentTicketId);

            if (emails.length === 0) {
                return message.reply('❌ لا يوجد إيميلات مرتبطة بهذه التكت');
            }

            const userId = emails[0].userId;
            const emailList = emails.map(e => e.email).join('\n');

            const embed = new EmbedBuilder()
                .setTitle('الإيميلات المصنوعة في هذا التكت')
                .setDescription(`المستخدم: <@${userId}>\nعدد الإيميلات: ${emails.length}`)
                .addFields({ name: 'قائمة الإيميلات', value: emailList.slice(0, 1000) })
                .setColor('#0099ff');

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('copy_all_emails')
                        .setLabel('📋 Copy All')
                        .setStyle(ButtonStyle.Primary)
                );

            const msg = await message.reply({ 
                embeds: [embed], 
                components: [row] 
            });

            const filter = i => i.customId === 'copy_all_emails' && i.user.id === message.author.id;
            const collector = msg.createMessageComponentCollector({ filter, time: 60000 });

            collector.on('collect', async i => {
                try {
                    await message.author.send(emailList);
                    await message.author.send('https://en.gmailcheck.com/');
                    
                    await i.reply({ 
                        content: '✅ تم إرسال جميع الإيميلات والرابط إلى الخاص', 
                        ephemeral: true 
                    });
                } catch (error) {
                    console.error('فشل إرسال الرسائل الخاصة:', error);
                    await i.reply({ 
                        content: '❌ تعذر إرسال الرسائل الخاصة. تأكد من فتح الخاص لديك', 
                        ephemeral: true 
                    });
                }
            });

            collector.on('end', () => {
                msg.edit({ components: [] }).catch(console.error);
            });
        }

        // ✅ أمر #find-drop
        if (message.content && message.content.toLowerCase().startsWith('#find-drop')) {
            const args = message.content.split(/\s+/);
            if (!args[1]) return message.reply('❗ اكتب الإيميل بعد الأمر.');

            const targetEmail = args[1].toLowerCase();
            const found = (data.gmails || []).find(e => e.email.toLowerCase() === targetEmail);

            if (!found) {
                return message.reply('🔍 لم يتم العثور على هذا الإيميل.');
            }

            return message.reply(`📧 هذا الإيميل تم إنشاؤه من قبل <@${found.userId}> في التكت <#${found.ticketId}>`);
        }

        // ✅ أمر $ticket
        if (message.content === '$ticket') {
            if (!message.member.roles.cache.has(config.allowedRoleId)) {
                return message.reply('🚫 ليس لديك صلاحية استخدام هذا الأمر.');
            }

            const embed = new EmbedBuilder()
                .setTitle('نظام دروب')
                .setDescription('تأكد انك تقدر تسوي حسابات قبل لا تفتح تكت عليها عقوبة');

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('open_ticket')
                        .setLabel('صنع حسابات دروب')
                        .setStyle(ButtonStyle.Primary)
                );

            await message.channel.send({ embeds: [embed], components: [row] });

            const logChannel = message.guild.channels.cache.get(config.logChannelId);
            if (logChannel) {
                await logChannel.send(`📨 تم استخدام أمر \`$ticket\` بواسطة <@${message.author.id}> في <#${message.channel.id}>`);
            }
        }

        // أوامر إدارة النقاط
        else if (message.content.startsWith('!+p ') || message.content.startsWith('!-p ')) {
            const allowedRoleId = config.allowedRoleId;
            if (!message.member.roles.cache.has(allowedRoleId)) {
                return message.reply('🚫 ياقلبي ما تقدر تزيد نقاط او تنقص فقط اصحاب سيرفر يقدرون.');
            }

            const args = message.content.split(/ +/);
            const mention = message.mentions.users.first();
            const points = parseInt(args[2]);

            if (!mention || isNaN(points) || points <= 0) {
                return message.reply('❗ استخدام خاطئ: !+p @المستخدم عدد_النقاط أو !-p @المستخدم عدد_النقاط');
            }

            if (message.content.startsWith('!+p ')) {
                client.topData[mention.id] = client.topData[mention.id] || { points: 0 };
                client.topData[mention.id].points += points;
                
                const { saveTopData } = require('../utils/loaders');
                await saveTopData(client);
                
                return message.reply(`✅ تم إضافة ${points} نقطة لـ ${mention.username} (الإجمالي: ${client.topData[mention.id].points})`);
            } else {
                client.topData[mention.id] = client.topData[mention.id] || { points: 0 };
                client.topData[mention.id].points = Math.max(0, client.topData[mention.id].points - points);
                
                if (client.topData[mention.id].points === 0) {
                    delete client.topData[mention.id];
                }
                
                const { saveTopData } = require('../utils/loaders');
                await saveTopData(client);
                
                return message.reply(`✅ تم خصم ${points} نقطة من ${mention.username} (الإجمالي: ${client.topData[mention.id]?.points || 0})`);
            }
        }

        else if (message.content.toLowerCase().startsWith('drop-ddd')) {
            if (!message.member.roles.cache.has(config.allowedRoleId)) {
                return message.reply('🚫 لا تملك صلاحية استخدام هذا الأمر.');
            }

            if (!fs.existsSync(dropPath)) {
                return message.reply('❌ لا يوجد ملف drop.json حالياً.');
            }

            try {
                fs.writeFileSync(dropPath, JSON.stringify({ emails: [], usedEmails: [], gmails: [] }, null, 2));
                client.dropData = { emails: [], usedEmails: [], gmails: [] };
                return message.reply('✅ تم حذف كل الإيميلات بنجاح.');
            } catch (err) {
                console.error('Error deleting drop content:', err);
                return message.reply('❌ حصل خطأ أثناء حذف الإيميلات.');
            }
        }

        else if (message.content.startsWith('!joinvs')) {
            if (!message.member.roles.cache.has(config.allowedRoleId)) {
                return message.reply('❌ ما عندك صلاحية استخدام هذا الأمر.');
            } 

            const channel = message.mentions.channels.first();
            if (!channel || channel.type !== 2) return message.reply('يجب منشن روم صوتي صالح.');

            const { joinVoiceChannel } = require('@discordjs/voice');
            joinVoiceChannel({
                channelId: channel.id,
                guildId: message.guild.id,
                adapterCreator: message.guild.voiceAdapterCreator,
                selfDeaf: false
            });

            message.reply(`تم دخول الروم الصوتي: ${channel.name}`);
        }

        if (message.content.toLowerCase() === '!check') {
            if (!message.member.roles.cache.has(config.allowedRoleId)) {
                return message.reply('🚫 ليس لديك صلاحية استخدام هذا الأمر.');
            }

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('check_accounts')
                        .setLabel('فحص حسابات')
                        .setStyle(ButtonStyle.Secondary)
                );

            await message.channel.send({ content: '📌 اضغط الزر أدناه لفحص الحسابات:', components: [row] });
        }

        if (message.content === '!top') {
            const allowedRoleId = config.allowedRoleId;
            if (!message.member.roles.cache.has(allowedRoleId)) {
                return message.reply('ما معك صلاحية يا قلبي شوف من <#1395036283889254580>');
            }
            
            const topArray = Object.entries(client.topData).map(([userId, data]) => ({
                userId,
                points: data.points
            })).sort((a, b) => b.points - a.points);

            if (topArray.length === 0) {
                return message.reply('لا توجد بيانات في التوب بعد.');
            }

            const embed = new EmbedBuilder()
                .setTitle('🏆 قائمة التوب - أعلى الأعضاء نقاطاً')
                .setDescription('**أعضاء قاموا بصنع أكبر عدد من حسابات دروب**\n\n' +
                    topArray.slice(0, 30).map((user, index) =>
                        `> ** #${index + 1} ---> <@${user.userId}> \n ${user.points}   ${config.emojis.ownerEmoji} نقطة**`
                    ).join('\n\n'))
                .setColor('#0099ff')
                .setFooter({ text: 'كل إيميل دروب = 2 نقطة' });

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('refresh_top')
                        .setLabel('🔄 تحديث')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setCustomId('top_help')
                        .setLabel('❓ شرح')
                        .setStyle(ButtonStyle.Secondary)
                );

            await message.channel.send({ embeds: [embed], components: [row] });
        }

        if (message.content.toLowerCase().startsWith('#setprice')) {
            if (!message.member.roles.cache.has(config.allowedRoleId)) {
                return message.reply('🚫 ليس لديك صلاحية استخدام هذا الأمر.');
            }

            const args = message.content.split(/\s+/);
            if (!args[1] || isNaN(args[1])) {
                return message.reply('❌ يرجى كتابة رقم صحيح للسعر. مثال: `#setprice 7000`');
            }

            client.emailPrice = parseInt(args[1], 10);
            return message.reply(`✅ تم تعيين سعر الإيميل إلى: ${client.emailPrice.toLocaleString()}`);
        }

        if (message.content.toLowerCase() === '!count-email') {
            if (!message.member.roles.cache.has(config.allowedRoleId)) {
                return message.reply('🚫 ليس لديك صلاحية استخدام هذا الأمر.');
            }

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('calc_credit')
                        .setLabel('احتساب كريدت')
                        .setStyle(ButtonStyle.Success)
                );

            await message.channel.send({ content: '📌 اضغط الزر لحساب الكريدت:', components: [row] });
        }
// أضف هذا الكود داخل الـ event الحالي
if (message.content.toLowerCase() === '!help') {
    const embed = new EmbedBuilder()
        .setTitle('🛠️ قائمة أوامر البوت - نظام الدروب')
        .setDescription('**جميع الأوامر المتاحة في النظام**')
        .setColor('#0099ff')
        .addFields(
            {
                name: '🎫 **أوامر نظام التذاكر**',
                value: 
                    '`$ticket` - إنشاء رسالة فتح تذاكر الدروب\n' +
                    '`#emails` - عرض الإيميلات المصنوعة في التكت الحالي (للمشرفين)\n' +
                    '`!joinvs @voice` - دخول البوت لروم صوتي'
            },
            {
                name: '🔍 **أوامر البحث والفحص**',
                value:
                    '`#find-drop [email]` - البحث عن إيميل دروب\n' +
                    '`!check` - فحص الحسابات المتاحة\n' +
                    '`!!stock` - عرض ستوك الإيميلات المتاحة'
            },
            {
                name: '📊 **أوامر الإحصائيات والنقاط**',
                value:
                    '`!top` - عرض قائمة الأعلى نقاطاً\n' +
                    '`!+p @user points` - إضافة نقاط لعضو\n' +
                    '`!-p @user points` - خصم نقاط من عضو\n' +
                    '`!count-email` - احتساب الكريدت'
            },
            {
                name: '⚙️ **أوامر الإدارة**',
                value:
                    '`#setprice [number]` - تحديد سعر الإيميل\n' +
                    '`drop-ddd` - حذف جميع الإيميلات من النظام'
            },
            {
                name: ' **الأوامر سلاش  (Slash Commands)**',
                value:
                    '`/check-drop` - عرض إحصائيات الحسابات\n' +
                    '`/delete_email [email]` - حذف إيميل من الستوك\n' +
                    '`/search [email]` - البحث عن إيميل\n' +
                    '`/set_drop_name [name]` - تحديد اسم العرض\n' +
                    '`/set_drop_pass [pass]` - وضع باسورد افتراضي\n' +
                    '`/set_g_drop` - إضافة ايميلات للستوك (مهم)'
            },
            {
                name: '📝 **ملاحظات مهمة**',
                value:
                    '• معظم الأوامر تتطلب صلاحية المشرفين\n' +
                    '• كل إيميل دروب = 2 نقطة في التوب\n' +
                    '• تأكد من فتح الخاص لتلقي الإيميلات'
            }
        )
        .setFooter({ text: 'Bot Commands • نظام إدارة حسابات الدروب' })
        .setTimestamp();

    await message.channel.send({ embeds: [embed] });
}
        if (message.content === '!!stock') {
            if (!message.member.roles.cache.has(config.allowedRoleId)) return;

            const availableCount = client.dropData.emails.length;
            const embed = new EmbedBuilder()
                .setTitle('📦 Stock Drop Emails')
                .setDescription(`**${availableCount} emails**`)
                .setColor('Blue')
                .setImage(config.images.stockImage);

            if (client.lastStockUser) {
                const user = await client.users.fetch(client.lastStockUser);
                embed.setThumbnail(user.displayAvatarURL({ size: 1024 }));
                embed.setFooter({ text: `آخر تحديث بواسطة ${user.username} • ${client.lastStockTime}` });
            }

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('refresh_stock')
                        .setLabel('🌐')
                        .setStyle(ButtonStyle.Primary)
                );

            await message.channel.send({ embeds: [embed], components: [row] });
        }
    }
};