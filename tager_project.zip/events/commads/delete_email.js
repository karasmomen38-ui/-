const { SlashCommandBuilder } = require('discord.js');
const { saveDropData } = require('../../utils/loaders');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('delete-email')
        .setDescription('حذف إيميلات من النظام')
        .addStringOption(opt => 
            opt.setName('emails')
                .setDescription('الإيميلات المراد حذفها (مفصولة بفواصل أو مسافات)')
                .setRequired(true)
        ),
    
    async execute(interaction, client) {
        const emailsInput = interaction.options.getString('emails');
        const emailsToDelete = emailsInput.split(/[\s,]+/).map(e => e.trim()).filter(Boolean);
        
        let deletedFromAvailable = 0;
        let deletedFromUsed = 0;
        let notFound = [];
        
        for (const email of emailsToDelete) {
            const availableIndex = client.dropData.emails.indexOf(email);
            if (availableIndex !== -1) {
                client.dropData.emails.splice(availableIndex, 1);
                deletedFromAvailable++;
                continue;
            }
            
            const usedIndex = client.dropData.usedEmails.findIndex(e => 
                typeof e === 'string' ? e === email : e.email === email
            );
            
            if (usedIndex !== -1) {
                client.dropData.usedEmails.splice(usedIndex, 1);
                deletedFromUsed++;
                continue;
            }
            
            notFound.push(email);
        }
        
        await saveDropData(client);
        
        let resultMessage = `✅ تم الحذف بنجاح:\n`;
        resultMessage += `- من المتاحة: ${deletedFromAvailable}\n`;
        resultMessage += `- من المستخدمة: ${deletedFromUsed}\n`;
        
        if (notFound.length > 0) {
            resultMessage += `\n❌ لم يتم العثور على: ${notFound.join(', ')}`;
        }
        
        return interaction.reply({ content: resultMessage, ephemeral: false });
    }
};