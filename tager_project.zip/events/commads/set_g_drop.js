const { SlashCommandBuilder } = require('discord.js');
const { saveDropData } = require('../../utils/loaders');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('set-g-drop')
        .setDescription('إضافة إيميلات دروب جديدة')
        .addStringOption(opt => opt.setName('emails').setDescription('الإيميلات مفصولة بأسطر').setRequired(true)),
    
    async execute(interaction, client) {
        const raw = interaction.options.getString('emails');
        const emails = raw.split(/\r?\n/).map(e => e.trim()).filter(Boolean);
        let added = 0;

        for (const email of emails) {
            const alreadyUsed = client.dropData.emails.includes(email) || client.dropData.usedEmails.find(e => e.email === email);
            if (!alreadyUsed) {
                client.dropData.emails.push(email);
                added++;
            }
        }

        await saveDropData(client);
        return interaction.reply({ content: `✅ تمت إضافة ${added} إيميل.`, ephemeral: false });
    }
};