const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('check-drop')
        .setDescription('عرض الإيميلات المتاحة والمستخدمة'),
    
    async execute(interaction, client) {
        const availableEmails = client.dropData.emails || [];
        const usedEmails = client.dropData.usedEmails.map(e => typeof e === 'string' ? e : e.email) || [];
        const confirmedCount = (client.dropData.gmails || []).length;

        const embed = new EmbedBuilder()
            .setTitle('📊 إحصائية حسابات دروب')
            .setColor('Blue')
            .addFields(
                { name: `✅ حسابات متوفرة (${availableEmails.length})`, value: availableEmails.length ? availableEmails.map(e => `- ${e}`).join('\n').slice(0, 1024) : 'لا يوجد' },
                { name: `🕓 حسابات قيد الاستخدام (${usedEmails.length})`, value: usedEmails.length ? usedEmails.map(e => `- ${e}`).join('\n').slice(0, 1024) : 'لا يوجد' },
                { name: `📬 حسابات مؤكدة الإنشاء`, value: `عددها: ${confirmedCount}` }
            );

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder().setCustomId('refresh_drop').setLabel('🔁 تحديث').setStyle(ButtonStyle.Primary),
                new ButtonBuilder().setCustomId('move_used_back').setLabel('♻️ تحويل قيد استخدام').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('delete_all_emails').setLabel('🗑️ حذف').setStyle(ButtonStyle.Danger)
            );

        return interaction.reply({ embeds: [embed], components: [row], ephemeral: false });
    }
};