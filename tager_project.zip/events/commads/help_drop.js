const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help-drop')
        .setDescription('عرض شرح لأوامر نظام دروب'),
    
    async execute(interaction, client) {
        const embed = new EmbedBuilder()
            .setTitle('📖 شرح أوامر نظام دروب')
            .setColor('Blue')
            .addFields(
                { name: '/set-g-drop emails:', value: 'لوضع ايميلات جديدة في النظام', inline: false },
                { name: '/check-emails', value: 'لفحص الإيميلات المتاحة والمستخدمة', inline: false },
                { name: '/set-g-pass', value: 'لتحديد باسورد مشترك للحسابات', inline: false },
                { name: '/set-g-name', value: 'لتحديد اسم واسم عائلة مشترك', inline: false },
                { name: '/delete-email', value: 'لحذف إيميلات من النظام', inline: false },
                { name: '!top', value: 'لعرض أعضاء التوب في نظام دروب', inline: false },
                { name: '#emails', value: 'لرؤية الإيميلات المصنوعة في التكت الحالي', inline: false },
                { name: '$ticket', value: 'لإظهار زر فتح تذكرة جديدة', inline: false },
                { name: '#find-drop', value: 'للبحث عن إيميل في التكتات', inline: false },
                { name: '!!stock', value: 'لرؤية ستوك الإيميلات المتاحة', inline: false }
            )
            .setFooter({ text: 'نظام إدارة حسابات دروب - جميع الحقوق محفوظة' });

        return interaction.reply({ embeds: [embed], ephemeral: false });
    }
};