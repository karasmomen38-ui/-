const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('set-drop-name')
        .setDescription('تعيين اسم العائلة')
        .addStringOption(opt => opt.setName('name').setDescription('الاسم').setRequired(true)),
    
    async execute(interaction, client) {
        client.dropName = interaction.options.getString('name');
        return interaction.reply({ content: `✅ تم تعيين الاسم: ${client.dropName}`, ephemeral: false });
    }
};