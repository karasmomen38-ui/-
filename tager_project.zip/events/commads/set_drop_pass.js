const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('set-drop-pass')
        .setDescription('تعيين باسورد مشترك')
        .addStringOption(opt => opt.setName('password').setDescription('الباسورد').setRequired(true)),
    
    async execute(interaction, client) {
        client.dropPass = interaction.options.getString('password');
        return interaction.reply({ content: `🔒 تم تعيين الباسورد: ${client.dropPass}`, ephemeral: false });
    }
};