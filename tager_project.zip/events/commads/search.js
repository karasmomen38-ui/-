const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('search')
        .setDescription('بحث دقيق عن الإيميلات في النظام')
        .addStringOption(opt => 
            opt.setName('emails')
                .setDescription('الإيميلات المراد البحث عنها (مفصولة بفواصل أو مسافات)')
                .setRequired(true)
        ),
    
    async execute(interaction, client) {
        const emailsInput = interaction.options.getString('emails');
        const emailsToSearch = emailsInput.split(/[\s,]+/).map(e => e.trim()).filter(Boolean);
        
        const foundInAvailable = [];
        const foundInUsed = [];
        const foundInGmails = [];
        const notFound = [];
        
        for (const email of emailsToSearch) {
            let found = false;
            
            if (client.dropData.emails.includes(email)) {
                foundInAvailable.push(email);
                found = true;
            }
            
            const inUsed = client.dropData.usedEmails.find(e => 
                typeof e === 'string' ? e === email : e.email === email
            );
            
            if (inUsed) {
                foundInUsed.push({
                    email: email,
                    info: typeof inUsed === 'string' ? 'لا يوجد معلومات إضافية' : `مستخدم من قبل: ${inUsed.userId ? `<@${inUsed.userId}>` : 'غير معروف'}`
                });
                found = true;
            }
            
            const inGmails = client.dropData.gmails ? client.dropData.gmails.filter(g => g.email === email) : [];
            
            if (inGmails.length > 0) {
                const ticketsInfo = inGmails.map(g => ({
                    ticketId: g.ticketId,
                    userId: g.userId
                }));
                
                foundInGmails.push({
                    email: email,
                    tickets: ticketsInfo,
                    count: inGmails.length
                });
                found = true;
            }
            
            if (!found) notFound.push(email);
        }
        
        const embed = new EmbedBuilder()
            .setTitle('🔍 نتائج البحث الدقيق')
            .setColor('#0099ff');
        
        if (foundInAvailable.length > 0) {
            embed.addFields({ name: `✅ متاحة للاستخدام (${foundInAvailable.length})`, value: foundInAvailable.join('\n'), inline: false });
        }
        
        if (foundInUsed.length > 0) {
            const usedList = foundInUsed.map(item => `- ${item.email} (${item.info})`).join('\n');
            embed.addFields({ name: `⏳ قيد الاستخدام (${foundInUsed.length})`, value: usedList, inline: false });
        }
        
        if (foundInGmails.length > 0) {
            const gmailList = foundInGmails.map(item => {
                let result = `- ${item.email} (موجود في ${item.count} تكت)`;
                if (item.tickets.length <= 3) {
                    result += '\n' + item.tickets.map(t => 
                        `  - التكت: ${t.ticketId} | المستخدم: ${t.userId ? `<@${t.userId}>` : 'غير معروف'}`
                    ).join('\n');
                } else {
                    result += `\n  - آخر تكت: ${item.tickets[0].ticketId} | المستخدم: ${item.tickets[0].userId ? `<@${item.tickets[0].userId}>` : 'غير معروف'}`;
                }
                return result;
            }).join('\n\n');
            
            embed.addFields({ name: `📭 مؤكدة الإنشاء (${foundInGmails.length})`, value: gmailList, inline: false });
        }
        
        if (notFound.length > 0) {
            embed.addFields({ name: `❌ غير موجودة (${notFound.length})`, value: notFound.join('\n'), inline: false });
        }
        
        const totalFound = foundInAvailable.length + foundInUsed.length + foundInGmails.length;
        embed.setDescription(`**ملخص البحث:**\nتم البحث عن ${emailsToSearch.length} إيميل\n- تم العثور على: ${totalFound}\n- غير موجودة: ${notFound.length}`);
        
        return interaction.reply({ embeds: [embed], ephemeral: false });
    }
};