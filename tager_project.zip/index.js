const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const fs = require('fs-extra');
const path = require('path');
const config = require('./config.json');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildVoiceStates
  ],
  partials: [Partials.Channel, Partials.Message, Partials.Reaction],
});

// تعريف المجموعات
client.commands = new Collection();
client.buttons = new Collection();
client.events = new Collection();

// تعيين المتغيرات العامة
client.dropData = { emails: [], usedEmails: [], gmails: [] };
client.topData = {};
client.ticketData = new Map();
client.emailPrice = config.emailPrice;
client.dropName = config.defaultDropName;
client.dropPass = config.defaultDropPass;
client.lastStockUser = null;
client.lastStockTime = null;
client.config = config;

// دالة لعرض هيكل المجلدات
function displayFolderStructure() {
  console.log('📦 هيكل المشروع:');
  console.log('├── 📂 events');
  console.log('│   ├── 📂 buttons');
  
  // عرض أزرار buttons
  try {
    const buttons = fs.readdirSync('./events/buttons');
    buttons.forEach(button => {
      console.log(`│   │   ├── ${button}`);
    });
    console.log('│   │   └── 📁 ' + buttons.length + ' ملف زر');
  } catch (error) {
    console.log('│   │   └── ❌ مجلد buttons غير موجود');
  }
  
  console.log('│   ├── 📂 commands');
  
  // عرض commands
  try {
    const commands = fs.readdirSync('./events/commands');
    commands.forEach(command => {
      console.log(`│   │   ├── ${command}`);
    });
    console.log('│   │   └── 📁 ' + commands.length + ' ملف أمر');
  } catch (error) {
    console.log('│   │   └── ❌ مجلد commands غير موجود');
  }
  
  // عرض الملفات الرئيسية في events
  console.log('│   ├── client_ready.js');
  console.log('│   ├── interaction_create.js');
  console.log('│   └── message_create.js');
  
  console.log('├── 📂 utils');
  console.log('│   ├── loaders.js');
  console.log('│   └── handlers.js');
  
  console.log('├── config.json');
  console.log('├── drop.json');
  console.log('├── top.json');
  console.log('├── package.json');
  console.log('└── index.js');
  console.log('\n🚀 Bot is starting...\n');
}

// تحميل الأدوات المساعدة
const { loadDropData, saveDropData, loadTopData, saveTopData } = require('./utils/loaders');
const { sendErrorToDiscord } = require('./utils/handlers');

// عرض الهيكل عند البدء
displayFolderStructure();

// تحميل الأحداث
const eventsPath = path.join(__dirname, 'events');
try {
  const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));
  
  console.log('✅ تحميل الأحداث:');
  for (const file of eventFiles) {
    const filePath = path.join(eventsPath, file);
    const event = require(filePath);
    
    if (event.once) {
      client.once(event.name, (...args) => event.execute(...args, client));
    } else {
      client.on(event.name, (...args) => event.execute(...args, client));
    }
    console.log(`   ↳ ${file} ✓`);
  }
} catch (error) {
  console.log('❌ خطأ في تحميل مجلد events:', error.message);
}

// تحميل معالجات الأزرار
const buttonsPath = path.join(__dirname, 'events', 'buttons');
try {
  const buttonFiles = fs.readdirSync(buttonsPath).filter(file => file.endsWith('.js'));
  
  console.log('✅ تحميل الأزرار:');
  for (const file of buttonFiles) {
    const filePath = path.join(buttonsPath, file);
    const button = require(filePath);
    client.buttons.set(button.name, button);
    console.log(`   ↳ ${file} ✓`);
  }
} catch (error) {
  console.log('❌ خطأ في تحميل مجلد buttons:', error.message);
}

// تحميل الأوامر
const commandsPath = path.join(__dirname, 'events', 'commands');
try {
  const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
  
  console.log('✅ تحميل الأوامر:');
  for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    const command = require(filePath);
    client.commands.set(command.data.name, command);
    console.log(`   ↳ ${file} ✓`);
  }
} catch (error) {
  console.log('❌ خطأ في تحميل مجلد commands:', error.message);
}

// معالجة الأخطاء
process.on('uncaughtException', (err) => {
  console.error('⚠️ حدث خطأ غير متوقع (uncaughtException):', err);
  sendErrorToDiscord(client, 'uncaughtException', err);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('⚠️ تم رفض وعد بدون معالجة (unhandledRejection):', reason);
  sendErrorToDiscord(client, 'unhandledRejection', reason);
});

// عند اكتمال التحميل
client.once('ready', () => {
  console.log('\n✅ تم تحميل جميع الملفات بنجاح!');
  console.log(`🤖 البوت يعمل باسم: ${client.user.tag}`);
  console.log('📍 جاهز للاستخدام...\n');
});

// تسجيل الدخول
client.login(config.token).catch(error => {
  console.error('❌ خطأ في تسجيل الدخول:', error.message);
});