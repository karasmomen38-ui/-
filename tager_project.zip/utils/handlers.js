const config = require('../config.json');

function sendErrorToDiscord(client, type, error) {
    try {
        const channel = client.channels.cache.get(config.errorLogChannelId);
        if (!channel) return;

        const shortError = String(error.stack || error).slice(0, 150) + (String(error).length > 150 ? '...' : '');

        channel.send({
            content: `⚠️ **${type}**\n\`\`\`${shortError}\`\`\``
        }).catch(console.error);
    } catch (err) {
        console.error('❌ فشل إرسال الخطأ إلى الديسكورد:', err);
    }
}

module.exports = { sendErrorToDiscord };