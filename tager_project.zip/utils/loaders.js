const fs = require('fs-extra');
const path = require('path');

const dropFile = path.join(__dirname, '..', 'drop.json');
const topFile = path.join(__dirname, '..', 'top.json');

async function loadDropData(client) {
    try {
        if (!(await fs.pathExists(dropFile))) {
            await fs.writeJSON(dropFile, { emails: [], usedEmails: [], gmails: [] }, { spaces: 2 });
            client.dropData = { emails: [], usedEmails: [], gmails: [] };
        } else {
            const data = await fs.readJSON(dropFile);
            client.dropData = {
                emails: data.emails || [],
                usedEmails: data.usedEmails || [],
                gmails: data.gmails || []
            };
        }
        console.log('✅ Drop data loaded successfully');
    } catch (err) {
        console.error('❌ Error loading drop.json:', err);
        client.dropData = { emails: [], usedEmails: [], gmails: [] };
    }
}

async function saveDropData(client) {
    try {
        await fs.writeJSON(dropFile, client.dropData, { spaces: 2 });
        console.log('✅ Drop data saved successfully');
    } catch (err) {
        console.error('❌ Error saving drop.json:', err);
    }
}

async function loadTopData(client) {
    try {
        if (!(await fs.pathExists(topFile))) {
            await fs.writeJSON(topFile, {}, { spaces: 2 });
            client.topData = {};
        } else {
            client.topData = await fs.readJSON(topFile);
        }
        console.log('✅ Top data loaded successfully');
    } catch (err) {
        console.error('❌ Error loading top.json:', err);
        client.topData = {};
    }
}

async function saveTopData(client) {
    try {
        await fs.writeJSON(topFile, client.topData, { spaces: 2 });
        console.log('✅ Top data saved successfully');
    } catch (err) {
        console.error('❌ Error saving top.json:', err);
    }
}

module.exports = { loadDropData, saveDropData, loadTopData, saveTopData };